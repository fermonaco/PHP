<?php

session_start();

if (isset($_FILES['fileUpload'])){
    if ($_FILES['fileUpload']['type']=='image/jpeg'){
        $fileName = microtime().'.jpeg';
       
        $fileName = preg_replace('/\s+/', '', $fileName);
        
        move_uploaded_file($_FILES['fileUpload']['tmp_name'],'uploads/'.$fileName );
        writeOnImage($fileName,$_POST['text']);
    }else {
        echo 'invalid file type';
    }    
}



function writeOnImage($jpeg,$txt) {

    $im  = imagecreatefromjpeg("uploads/".$jpeg);
    $color = imagecolorallocate($im, 0, 0, 255);
    imagestring($im, 5, 0, 0, $txt, $color);

    header('Content-type: image/jpeg');
    $newFile = "new_uploads/".$jpeg;
    
    imagejpeg($im,$newFile);
    imagedestroy($im);
    
    $_SESSION['newphoto'] = $newFile; 
    header("Content-Type: text/html");
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fernando</title>
</head>

<body>
        <?php
        if (isset($_SESSION['newphoto']))
            {
                $img = $_SESSION['newphoto'];
                echo "<img src='".$img."' >";
            }
        ?>
</body>
</html>