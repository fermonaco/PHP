<!DOCTYPE html>
<html lang="en">
<head>
   <title>Upload Form</title>
    
    <style>
        #position {
            width: 295px;
            height: auto;
            margin-top: 30px;
            background-color: coral;
            box-shadow: 10px 10px 5px #888888;
        } 
    </style>
    
</head>
    
    
<body>
    
    <h1>Upload Form:</h1>
    
    <P>Type your name below...</P>
    

    
   <form action="picture.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="text" style="background-color:transparent;">
        <div id="position">
            <input type="file" name="fileUpload">
            <input type="submit" value="Send">
   </form>
       </div>
    
    <p>Click on browse button to add some file...</p>
</body>
</html>
