<?php

require("employee.php");
require("custodian.php");



//emp1
$emp1 = new custodian();
$emp1->setFirstName("Camilla");
$emp1->setLastName("Monaco");
$emp1->setEmpNumber("1");
$emp1->setCertificationLevel("A");


//emp2
$emp2 = new custodian();
$emp2->setFirstName("Ana");
$emp2->setLastName("Luiza");
$emp2->setEmpNumber("2");
$emp2->setCertificationLevel("AB");

echo "Employee: ".$emp1->getEmpNumber();
echo "<br>First name: ".$emp1->getFirstName()."<br>Last name: ".$emp1->getLastName();
echo "<br>Level: ".$emp1->getCertificationLevel();
echo "<hr>";
echo "Employee: ".$emp2->getEmpNumber();
echo "<br>First name: ".$emp2->getFirstName()."<br>Last name: ".$emp2->getLastName();
echo "<br>Level: ".$emp2->getCertificationLevel();

?>  