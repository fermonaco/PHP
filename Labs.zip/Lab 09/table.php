<?php

    $host = "localhost"; //server
    $username = "root"; //user from server
    $password = ""; //no password from server
    $database = "lesson09"; //database created befor this


$link = mysqli_connect($host, $username, $password, $database); //link to connect to server


$query = "select * from books"; // select table to show


$results = mysqli_query($link, $query);





$row = mysqli_fetch_array($results);
echo $row['id'];
echo '<br />';
echo $row['title'];
echo '<br />';
echo $row['author'];
echo '<br />';
echo $row['published_year'];
echo '<br />';

$row = mysqli_fetch_array($results);
echo '<br />';
echo $row['id'];
echo '<br />';
echo $row['title'];
echo '<br />';
echo $row['author'];
echo '<br />';
echo $row['published_year'];
echo '<br />';

$row = mysqli_fetch_array($results);
echo '<br />';
echo $row['id'];
echo '<br />';
echo $row['title'];
echo '<br />';
echo $row['author'];
echo '<br />';
echo $row['published_year'];
echo '<br />';
?>


<!-- CMD commands:

cd c:\xampp\mysql\bin

mysql -h localhost -u root

create database lesson09;

use lesson09;

create table books(

id int auto_increment,
title varchar(255) not null,
author varchar(255) not null,
published_year int not null,
primary key(id));


insert into books(id, title, author, published_year) value("1", "Book 1", "John", "2005");
insert into books(id, title, author, published_year) value("2", "Book 2", "Jane", "2010");
insert into books(id, title, author, published_year) value("3", "Book 3", "Joe", "2012");

select * from books
-->