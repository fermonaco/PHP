<?php

		echo "Presentation... <br /><br />";
	
	$hi = "Hi buddy! <br/>";
	$contact = "Type your email below...";
		
		echo $hi;
		echo "<br>"; //line space
		echo $contact;
		echo "<br>"; //line space
?>


<!--html form to insert email-->
<form>
	<input type="text" name="name" value="email@email.com">
</form>
<!--end of html form to insert email-->


<?php
		echo "<br>"; //line space
		echo "Any comments?";
		echo "<br>"; //line space
?>


<!--html funcion space to write comments-->
<textarea name="comments" rows="10" cols="40">Write here your comment...</textarea>
<!--end of html funcion space to write comments-->


<!--from here starts send button functions-->
<form action="" method="post">
    <input type="submit" name="send" value="Send">
 </form>
  
  <?php
   if (isset($_POST['send'])) // php code to send button
    {
  ?>

<!--html funcion to say thx-->
<div>
<p>Thanks!</p>
</div>
<!--end of html funcion to say thx-->


<?php
    }
?>
<!--end of send button functions-->