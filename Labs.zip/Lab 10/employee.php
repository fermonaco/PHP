<?php

class Employee {
    
    private $firstName;
    private $lastName;
    private $empNumber;
    
    
    
    public function setfirstName($firstName) {
    $this->firstName = $firstName;
    }

    public function setLastName($lastName) {
    $this->lastName = $lastName;
    }
    
    public function setEmpNumber($empNumber) {
    $this->empNumber = $empNumber;
    }

    
    
    
    public function getFirstName() {
        return $this->firstName;
    }
    
    public function getLastName() {
        return $this->lastName;
    }
    
    public function getEmpNumber() {
        return $this->empNumber;
    }
    
}

?>