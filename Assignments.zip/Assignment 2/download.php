<?php 

$file_name = "uploads/".$_GET['name'];

header('Content-Disposition: attachment; filename="'.basename($file_name).'"');
readfile($file_name);
exit();

?>