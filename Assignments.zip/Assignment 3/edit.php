<?php
$message ='';
$num ='1';

session_start();

require ("includes/functions.php");

if (!isset($_SESSION['admin'])){
	header("Location: login.php");
	exit();
}

if (!isset($_SESSION['idVarGet'])){
	$idVarGet = '';
	$firstNameVar = '';
	$lastNameVar ='';
	$titleVar ='';
	$commVar ='';
	$priVar = '0';	
}

if(count($_POST) > 0){
	echo "<hr>";
    $fieldInput = validateFields($_POST);
	$fileNameToMove = $_FILES['file']['name'];
    $fileInput  = isValidFile($_FILES['file']);

		if($fileInput != false){
			$fieldInput['file'] = $_FILES['file']['tmp_name'];
			update($_POST['firstname'], $_POST['lastname'], $_POST['title'], $_POST['comment'], $_POST['priority'], $fileNameToMove, $_SESSION['id']);
		} else {
            echo "<hr>".$_POST['firstname'];
        }		
        } else {
        if(isset($_GET['id']) &&  (is_numeric($_GET['id'])))
        {
            $id = $_GET['id'];
            $_SESSION['id'] =  $id;
            $results = getPostsByID($id);
            $firstNameVar = trim($results[0]['firstname']);
            $lastNameVar = trim($results[0]['lastname']);
            $titleVar = trim($results[0]['title']);
            $commVar = trim($results[0]['comment']);
            $priVar = trim($results[0]['priority']);
            $fileVar = trim($results[0]['filename']);
        } else {
            echo '<p><em><b>***Your request was not found.***</b></em></p>';
        }
    }
?>



    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Post</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="css/style.css" rel="stylesheet">

    </head>

    <body>

        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <h3 class="login-panel text-center text-muted">It is now
                    <?php echo date('l F \t\h\e dS, Y', time());?>
                </h3>
                <?php echo $message; ?>
            </div>
        </div>

        <div id="newPost" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <form role="form" method="post" action="edit.php" enctype="multipart/form-data">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Edit Post</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <input class="form-control" placeholder="First Name" name="firstname" value="<?php echo $firstNameVar; ?>">
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Last Name" name="lastname" value="<?php echo $lastNameVar; ?>">
                            </div>
                            <div class="form-group">
                                <label>Title</label>
                                <input class="form-control" placeholder="" name="title" value="<?php echo $titleVar; ?>">
                            </div>
                            <div class="form-group">
                                <label>Comment</label>
                                <textarea class="form-control" rows="3" name="comment"><?php echo $commVar; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Priority</label>
                                <?php 
                            echo '<select class="form-control" name="priority">';
                            if($num == '1'){
                            echo
                                '<option value="1" selected>Important</option>
                                 <option value="2">High</option>
                                 <option value="3">Normal</option>';
                            }else if($num == '2'){
                                echo
                                '<option value="1" >Important</option>
                                 <option value="2" selected>High</option>
                                 <option value="3">Normal</option>';
                            }else if($num == '3'){
                                echo
                                '<option value="1">Important</option>
                                 <option value="2">High</option>
                                 <option value="3" selected>Normal</option>';
                            }
                            echo '</select>';
								?>
                            </div>
                            <div class="form-group">
                                <label>Image</label><br>
                                <input name="file" type="file" />

                            </div>
                        </div>
                        <div class="modal-footer">
                            <a href="search.php" class="btn btn-default"> Close</a>
                            <input type="submit" class="btn btn-primary" value="Update Post!" />
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </form>
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </body>

    </html>
