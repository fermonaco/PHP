<?php

function write($content){
	$myfile = fopen('posts.txt', "a") or die("Unable to open file!");
	$line = $content."\r\n";
	fwrite($myfile, $line);
	fclose($myfile);
}



function readPost(){

	$row = 1;
	if (($handle = fopen('posts.txt', "r")) != FALSE) {
		while (($data = fgetcsv($handle, 1000, ",")) != FALSE) {
			$num = count($data);
			if ($num == 6) {
			$row++;
			$first_Name =$data[0];
			$last_Name = $data[1];
			$comment = $data[2];
			$priority = $data[3];
			$date = $data[4];
			$image = $data[5]; 	



			echo '<div class="row">';
			echo '	<div class="col-md-6 col-md-offset-3">';
			echo '		<div class="panel panel-info">';
			echo '			<div class="panel-heading">';
			echo '				<span>';
            echo '               Post '.$row;
            echo '            </span>';
			echo ' 					<span class="pull-right text-muted">';
            echo         moments(time() - $date);
            echo '            </span>';
			echo ' 				</div>';
			echo ' 				<div class="panel-body">';
			echo ' 					<p class="text-muted">Posted on ';
			echo                    date('F dS, Y.', $date);
			echo ' 					</p>';
			echo '					<p>';
			echo 						$comment;
			echo '					</p>';
			echo '	                <div class="img-box">';
            echo '                		<img class="img-thumbnail img-responsive" src="uploads/'.trim($image).'"/>';
			echo '					</div> ';
			echo '				</div>';
			echo '				<div class="panel-footer">';
			echo '					<p> By ';
			echo 							$first_Name.' '.$last_Name;
			echo '						</p>';
			echo '					</div>';
			echo '				</div>';
			echo '			</div>';
			echo '</div>';
			}
		}
		fclose($handle);
	}
}
?>