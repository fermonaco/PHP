<?php


require ("includes/functions.php");



$message = '';
$firstName  = '';
$lastName = '';
$phoneNumber = '';
$dob = '';



if(isset($_COOKIE['firstName'])) {
    
    $firstName =  $_COOKIE['firstName'];
}


if(isset($_COOKIE['lastName'])) {
    
    $lastName =  $_COOKIE['lastName'];
}


if(isset($_COOKIE['phoneNumber'])) {
    
    $phoneNumber =  $_COOKIE['phoneNumber'];
}


if(isset($_COOKIE['dob'])) {
    
    $dob =  $_COOKIE['dob'];
}





if(count($_POST) > 0) //if $_POST > 0, setcookies below for all fields.
{

	setcookie('firstName',$_POST['firstName'],time()+60*20);
	setcookie('lastName',$_POST['lastName'],time()+60*20);
	setcookie('phoneNumber',$_POST['phoneNumber'],time()+60*20);
	setcookie('dob',$_POST['dob'],time()+60*20);


    $check = checkSignUp($_POST);

    if($check === true)
    {
        $message = '<div class="alert alert-success text-center">
                        Thank you for signing up!
                    </div>';
    }
    else
    {
        $message = '<div class="alert alert-danger text-center">
                        '.$check.' 
                    </div>';
    }
}
?>







<!DOCTYPE html>
<html>
<head>
    <title>COMP 3015</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<div id="wrapper">

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <h1 class="login-panel text-center text-muted">COMP 3015</h1>

                <?php echo $message; ?> <!-- PHP -->

                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Create Account</h3>
                    </div>
                    <div class="panel-body">
                        <form name="signup" role="form" action="signup.php" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" name="firstName" placeholder="First Name" type="text" value="<?php echo $firstName;?>" autofocus /> <!-- PHP -->
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="lastName" placeholder="Last Name" value="<?php echo $lastName;?>"  type="text"/>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="password" placeholder="Password" type="password"/>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="phoneNumber" placeholder="Phone Number" value="<?php echo $phoneNumber;?>"  type="text" />
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="dob" placeholder="Date of Birth" value="<?php echo $dob;?>"  type="text" />
                                </div>
                                <input type="submit" class="btn btn-lg btn-info btn-block" value="Sign Up!"/>
                            </fieldset>
                        </form>
                    </div>
                </div>
                <a class="btn btn-sm btn-default" href="login.php">Login</a>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>