<?php

session_start();

require ("includes/functions.php");

if (!isset($_SESSION['admin'])){
	header("Location: login.php");
	exit();
}

$logins = logins();


$loginsTotal = 0;

?>






    <!DOCTYPE html>
    <html>

    <head>
        <title>COMP 3015</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>

        <div id="wrapper">

            <div class="container">

                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <h3 class="login-panel text-center text-muted">Users</h3>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <a href="search.php" class="btn btn-default"><i class="fa fa-arrow-circle-left"> </i> Back</a>
                        <hr/>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-md-offset-3">

                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Users
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">

                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>DOB</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
								   	if(count($logins) > 0){
										$loginsTotal = count($logins);
                                        foreach($logins as $login){

											echo '                                    
											<tr>
                                        		<td>'.$login['firstname'].'</td>
                                        		<td>'.$login['lastname'].'</td>
                                        		<td>'.$login['dob'].'</td>
                                    		</tr>';
											}
										}
									
									?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->

                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <p class="text-center text-muted">
                            Total users:
                            <?php echo $loginsTotal ?>.
                        </p>
                    </div>
                </div>

            </div>
        </div>

    </body>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </html>
