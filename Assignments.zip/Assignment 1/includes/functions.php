<?php


//** function moments **//
function moments($seconds) {
    if($seconds < 60 * 60 * 24 * 30)
    {
        return "within the month";
    }
        return "a while ago";
}





//** function checkInput **//
function checkInput($input) {
    if(trim($input['firstName']) == '' ||
        trim($input['lastName']) == '' ||
        trim($input['title'])    == '' ||
        trim($input['comment'])  == '' ||
        trim($input['priority']) == '')
    {
        return false;
    }
        return true;
}





//** function saveInput **//
function saveInput($data) {
	$line  = PHP_EOL;
    $line .= $data['firstName'] . '|';
    $line .= $data['lastName']  . '|';
    $line .= $data['title']     . '|';
    $line .= str_replace("\n", " ", $data['comment']).'|';
    $line .= $data['priority']  . '|';
    $line .= $data['filename']  . '|';
    $line .= time();
    $line .= PHP_EOL;

    $fp = fopen("posts.txt", "a+");
    fwrite($fp, $line);
    fclose($fp);
}





//** function getPosts **//
function getPosts() {
        $posts = [];

    if(file_exists("posts.txt")){
        $posts = file("posts.txt");
		
		$count = 0;
		$importants = sortPosts($posts, '1','');
		$highs = sortPosts($posts, '2','');
		$normals =sortPosts($posts, '3','');

        
		if ((count($importants) >= 1)||(count($highs) >= 1)||(count($normals) >= 1)) {

			if 	(count($importants) >= 1) {
				publicPost($importants);
			}
			if 	(count($highs) >= 1) {
				publicPost($highs);	
			}
			if 	(count($normals) >= 1) {
				publicPost($normals);	
			}
		}else {
			postError('No Valid Post Found', 'error.png');
		}


    }else {
			 postError('File Posts.txt Not Found', 'notfound.jpg');
	}
}





//** function sortPosts **//
function sortPosts($sortPosts,$sortPriority,$searchValue) {
		$sortedPosts =[];
        foreach($sortPosts as $postSort){
			$words = preg_split("/\|/", $postSort);

			if (count($words) == 7 ){
				$priority   = trim($words[4]);
				$comment    = trim($words[3]);
				if (($priority == $sortPriority) && ($searchValue === '')) {
					$sortedPosts[] =  $words;
				}else {
				$pos = stripos($comment, $searchValue);
				if (($priority == $sortPriority) && ($pos !== false)) {
						$sortedPosts[] =  $words;
					} 
				}
			}
		}	
	return $sortedPosts;
}





//** function checkSignUp **//
function checkSignUp($data) {
    $valid = false;

        if(trim($data['firstName']) == '' ||
        trim($data['lastName']) == '' ||
        trim($data['password'])  == '' ||
        trim($data['phoneNumber'])    == '' ||
        trim($data['dob']) == '')
    {
        $valid = "All inputs are required.";
    }
    elseif(!preg_match("/^[A-Z]+$/i", trim($data['firstName'])))
    {
        $valid = 'First Name needs to be alphabetical only.';
    }
    elseif(!preg_match("/^[A-Z]+$/i", trim($data['lastName'])))
    {
        $valid = 'Last Name needs to be alphabetical only';
    }
    elseif(!preg_match("/^.*([0-9]+.*[A-Z])|([A-Z]+.*[0-9]+).*$/i", trim($data['password'])))
    {
        $valid = 'Password must contain at least a number and a letter.';
    }
    elseif(!preg_match("/^((\([0-9]{3}\))|([0-9]{3}))?( |-)?[0-9]{3}( |-)?[0-9]{4}$/", trim($data['phoneNumber'])))
    {
        $valid = 'Phone Number must be in the format of (000) 000 0000.';
    }
    elseif(!preg_match("/^(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)-[0-9]{2}-[0-9]{4}$/i", trim($data['dob'])))
    {
        $valid = 'Date of Birth must be in the format of MMM-DD-YYYY.';
    }
    else
    {
        $valid = true;
    }

    return $valid;
}





//** function mypost **//
function mypost($priority,$title,$moment,$formattedPostedTime,$comment,$filename,$formattedAuthor) {
	if ($priority == 1) {
			$vClassPriority = 'danger';
		}elseif ($priority == 2) {
			$vClassPriority = 'warning';
		}elseif ($priority == 3) {
			$vClassPriority = 'info';
		}
    
	 echo '
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="panel panel-'.$vClassPriority.'">
                            <div class="panel-heading">
                                <span>
                                    '.$title.'
                                </span>
                                <span class="pull-right text-muted">
                                '.$moment.'
                                </span>
                            </div>
                            <div class="panel-body">
                                <p class="text-muted">Posted on
                                    '.$formattedPostedTime.'
                                </p>
                                <p>
                                    '.$comment.'
                                </p>
                                <div class="img-box">
                                    <img class="img-thumbnail img-responsive" src="uploads/'.$filename.'"/>
                                </div>
                            </div>
                            <div class="panel-footer">
                                <p> By
                                    ' . $formattedAuthor .'
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            ';
}





//** function checkPost **//
function checkPost($data) {
    $valid = false;

    if(trim($data['firstName']) == '' ||
        trim($data['lastName']) == '' ||
        trim($data['title'])  == '' ||
        trim($data['comment'])    == '' ||
        trim($data['priority']) == '')
    {
        $valid = "All inputs are required!";
    }
    elseif(!preg_match("/^[A-Z \s]+$/i", trim($data['firstName'])))
    {
        $valid = 'First Name needs to be alphabetical only.';
    }
    elseif(!preg_match("/^[A-Z \s]+$/i", trim($data['lastName'])))
    {
        $valid = 'Last Name needs to be alphabetical only';
    }
    elseif(!preg_match("/^[A-Z \s]+$/i", trim($data['title'])))
    {
        $valid = 'Title needs to be alphabetical only.';
    }
	elseif(!preg_match("/^[A-Z \s\p{P}]+$/i", trim($data['comment'])))	
    {
        $valid = 'The comment should not have "<", ">"or "|" .';
    }
	elseif(!preg_match("/^[0-9]*$/", trim($data['priority']))) 
    {
        $valid = 'Priority should be just numbers.';
    }
	elseif(!preg_match("/^[0-9]*$/", trim($data['priority']))) 
    {
        $valid = 'Priority should be just numbers.';
    }
    else
    {
        $valid = true;
    }

    return $valid;
}





//** function postError **//
function postError($msg, $file) {
	echo '
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="panel panel-danger">
                            <div class="panel-heading">
                                <span>
                                    <h1><b>'.$msg.'</b></h1>
                                </span>
                                <span class="pull-right text-muted">
                                 
                                </span>
                            </div>
                            <div class="panel-body">
                                <p class="text-muted"> 
                                     
                                </p>
                                <p>
                             
                                </p>
                                <div class="img-box">
                                    <img class="img-thumbnail img-responsive" src="uploads/'.$file.'"/>
                                </div>
                            </div>
                            <div class="panel-footer">
                                <p>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            ';
}






//** function publicPost **//
function publicPost($arrayPost) {
			 foreach($arrayPost as $postInfo) {

				$author     = trim($postInfo[0]) . ' ' . trim($postInfo[1]);		
				$title      = trim($postInfo[2]);		
				$comment    = trim($postInfo[3]);	
				$priority   = trim($postInfo[4]); 
				$filename   = trim($postInfo[5]);
				$postedTime = trim($postInfo[6]);

				$moment                 = moments(time() - $postedTime);
				$formattedCurrentTime   = date('l F \t\h\e dS, Y', time());
				$formattedPostedTime    = date('l F \t\h\e dS, Y', $postedTime);
				$formattedAuthor        = ucwords(strtolower($author));
			 	
				mypost($priority,$title,$moment,$formattedPostedTime,$comment,$filename,$formattedAuthor);
        		}
}






//** function validateSearch **//
function validateSearch($search) {
	$msg = '';
	if(!preg_match("/^[A-Z \s]+$/i", trim($search))) {
		$msg = 'needs to be alphabetical only.';
	}else{
		searchPosts($search);
	}
	if (!$msg == '') {
			echo	'<div class="alert alert-danger alert-dismissable text-center">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					 ' .$msg.'
				</div>';
	}
}






//** function searchPosts **//
function searchPosts($search) {
	if(file_exists("posts.txt")) {
			$posts = file("posts.txt");	
			$importants = sortPosts($posts, '1',$search);
			$highs = sortPosts($posts, '2',$search);
			$normals =sortPosts($posts, '3',$search);
			
			$countFoundsImportants = count($importants);
			$countFoundsHighs = count($highs);
			$countFoundsNormals = count($normals);
	
			$countSearchFounds = ($countFoundsImportants+$countFoundsHighs+$countFoundsNormals);
			$_SESSION['countSearchFounds'] = $countSearchFounds;
		
			if 	($countFoundsImportants >= 1) {
				postSearch($importants);
			}
			if 	($countFoundsHighs >= 1) {
				postSearch($highs);
			}
			if 	($countFoundsNormals >= 1) {
				postSearch($normals);
			}
	}
}






//** function postSearch **//
function postSearch($resultSearch) {
					foreach($resultSearch as $postInfo) {
					$class = 'info';
					$author     = trim($postInfo[0]) . ' ' . trim($postInfo[1]);		
					$title      = trim($postInfo[2]);		
					$comment    = trim($postInfo[3]);	
					$priority   = trim($postInfo[4]); 
					$filename   = trim($postInfo[5]);
					$postedTime = trim($postInfo[6]);

					$formattedCurrentTime   = date('F j, Y', $postedTime);
						
						
					if ($priority == 1)	{
						$class = 'danger';
					}elseif ($priority == 2) {
						$class = 'warning';
					}

					echo "<tr class='$class'>
							<td>$author</td>
							<td>$title</td>
							<td>$formattedCurrentTime</td>
						</tr>";	
				}
}