<?php

class custodian extends employee {
    
    private $certificationLevel;
    
    
    
    
    public function setCertificationLevel($certificationLevel) {
        $this->certificationLevel = $certificationLevel;
    }
    
    
    
    public function getCertificationLevel() {
        return $this->certificationLevel;
    }

}

?>