<?php
$message = '';
$sub_msg ='';

if(count($_POST) > 0) {
    
            if(trim($_POST['firstName']) == '' || trim($_POST['lastName']) == '' || trim($_POST['password']) == '' || trim($_POST['phoneNumber']) == '' || trim($_POST['dob']) == '') {
                
            $message = '<div class="alert alert-warning alert-dismissable text-center">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        All inputs are required!
                    </div>';
            }
            else {
			$firstName 		= 	trim(ucfirst($_POST['firstName']));
			$lastName 		= 	trim(ucfirst($_POST['lastName']));
			$password 		= 	trim(ucfirst($_POST['password']));
			$phoneNumber 	= 	trim(ucfirst($_POST['phoneNumber']));
			$dob 			= 	trim(ucfirst($_POST['dob']));


				
			if (preg_match('/^[a-z .\-]+$/i', $firstName) ){
			$message = '<div class="alert alert-success alert-dismissable text-center">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        Thank you ' . $_POST['firstName'] . ' ' . $_POST['lastName'] . '! .
                        ' . date('F dS, Y', time()).'.
                    </div>';
			}
            else {
				$sub_msg = 'First Name must be only character (alphabetical only).<br/>';
			}
		
			if (preg_match('/^[a-z .\-]+$/i', $lastName) ){
			$message = '<div class="alert alert-success alert-dismissable text-center">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        Thank you ' . $_POST['firstName'] . ' ' . $_POST['lastName'] . '! .
                        ' . date('F dS, Y', time()).'.
                    </div>';
			}
            else {
				$sub_msg = $sub_msg.'<br/>Last Name must be only character <br/> (alphabetical only).<br/>';
			}
		
			$uppercase = preg_match('@[A-Z]@', $password);
			$lowercase = preg_match('@[a-z]@', $password);
			

			if(!$uppercase || !$lowercase) {
				$sub_msg = $sub_msg.'<br/>Password must have at least 1 upper Character and 1 lower.</br>';
			}


        
        
			$PhoneRegex = '/^(\(\d{3}\)[- ]?|\d{3}[- ]?)?\d{3}[- ]?\d{4}$/';
			if ( preg_match($PhoneRegex, $phoneNumber))
			{
			}
            else {
				$sub_msg = $sub_msg.'<br/>Phone Number must have 7 or 10 Digits.<br/>
				Formats Accepted :              <br>		
				(604)1231234 is valid           <br>
				604 123 1234 is valid           <br>
				604-123-1234 is valid           <br>
				(604) 123 1234 is valid         <br>
				6041231234 is valid             <br>
				1231234 and 1231231234 is valid <br>
				<b><em>(6041231234 and 604)1231234 is not valid</b></em><br/>';
			}
		
			$DateRegex2 = '/^'. //start regex
				'(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)'. //months
				'[\s{1}|\/|-]'. //separators accepted
				'(3[0-1]|2[0-9]|1[0-9]|0[1-9])'. //day of the month
				'[\s{1}|\/|-]'. //separators
				'\d{4}'. //year
				'$/i';

			if (!preg_match($DateRegex2, $dob)){
				$sub_msg = $sub_msg.' <br/>Date of Birth: Correct format of MMM-DD-YYYY.<br>
					<em>eg. JAN-01-1980 is valid!</em>';
			}
		
		
			if ($sub_msg != '') {
			$message = '<div class="alert alert-success alert-dismissable text-center">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        '.$sub_msg.'
                        </div>';			
			}
    }
}
?>








<!DOCTYPE html>
<html>
<head>
    <title>COMP 3015</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<div id="wrapper">

    <div class="container">

        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <h1 class="login-panel text-center text-muted">COMP 3015</h1>
				<?php echo $message; ?>
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Create Account</h3>
                    </div>
                    <div class="panel-body">
                        <form name="signup" role="form" action="signup.php" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" name="firstName" placeholder="First Name" type="text" autofocus />
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="lastName" placeholder="Last Name" type="text"/>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="password" placeholder="Password" type="password"/>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="phoneNumber" placeholder="Phone Number" type="text" />
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="dob" placeholder="Date of Birth" type="text" />
                                </div>
                                <input type="submit" class="btn btn-lg btn-info btn-block" value="Sign Up!"/>
                            </fieldset>
                        </form>
                    </div>
                </div>
                <a class="btn btn-sm btn-default" href="login.php">Login</a>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
