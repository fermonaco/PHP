<?php

require ("includes/functions.php");

session_start();

if (!isset($_SESSION['admin'])){
	header("Location: login.php");
	exit();
}


$idVar = '';
$firstNameVar = '1';
$lastNameVar ='2';
$titleVar ='';
$commVar ='';
$priVar = '0';



if(isset($_GET['id']) && (is_numeric($_GET['id'])))
{
    $Id = $_GET['id'];
    $results = getPostsByID($Id);
	$count = count($results);

	if ($count == 1) {
		deletePostByID($Id);		
	} else {
		echo '<p><em><b>The Post you requested was not found.</b></em></p>';		
	}
    } else {
		echo '<p><em><b>The Post you requested was not found.</b></em></p>';
}


?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Delete Post</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <a href="search.php"><button id="backButt">Back</button></a>
    </body>

    </html>
